<!--
WARNING Pull Requests made to this repository cannot be merged

If you have not already done so, please read the Contributing document, found here: https://github.com/webfashionist/RichText/blob/master/CONTRIBUTING.md

The pull requests to this project must be made under the AGPL-3.0 license.
-->

## Overview

This pull request [introduces/changes/removes] [functionality/feature].

(Please write a summary of your pull request here. This paragraph should go into detail about what is changing, the motivation behind this change, and the approach you took.)



**I understand that:**

- [ ] I'm submitting this PR for reference only. It shows an example of what I'd like to see changed but
  I understand that it will not be merged and I will not be listed as a contributor on this project.